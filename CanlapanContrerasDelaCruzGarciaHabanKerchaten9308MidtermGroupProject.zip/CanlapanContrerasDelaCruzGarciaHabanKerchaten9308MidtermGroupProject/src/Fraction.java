public class Fraction {
}
