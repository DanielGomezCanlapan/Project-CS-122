public class FractionTester {
}
