public class MixedFraction {
}
